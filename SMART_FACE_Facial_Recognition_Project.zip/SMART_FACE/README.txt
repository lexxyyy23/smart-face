SMART FACE - Facial Recognition & Attendance Management System
===============================================================

WHAT THIS PROJECT DOES
- Registers a person by capturing a webcam image.
- Converts the face into a numerical face descriptor.
- Detects faces through the webcam.
- Compares the live descriptor with registered descriptors.
- Displays the recognized person's name.
- Records attendance events in browser localStorage.
- Provides a dashboard and attendance table.

TECHNOLOGY
- HTML5 / CSS3 / JavaScript
- face-api.js + TensorFlow.js
- Browser MediaDevices API for webcam
- localStorage for the demo database

HOW TO RUN
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Install the VS Code "Live Server" extension, or use another local HTTP server.
4. Open index.html through localhost (do not simply double-click the file if the browser blocks camera/model loading).
5. Allow camera access.
6. Register at least one person.
7. Go to Live Recognition and test the registered face.
8. Open Attendance Records to show the recognition history.

IMPORTANT
The first load requires internet because the AI library and model weights are loaded from public CDNs.
For a production system, move the model files into a local /models directory and use a real backend/database.

DEFENSE DEMONSTRATION FLOW
1. Introduce the problem: manual attendance can be slow and vulnerable to proxy attendance.
2. Explain the solution: the system uses facial descriptors to compare a live face with registered users.
3. Show the Dashboard.
4. Register a sample student.
5. Start Live Recognition and let the camera identify the student.
6. Point out the detected face box, name and confidence/distance result.
7. Open Attendance Records and show the automatically created record.
8. Explain the architecture: webcam -> face detection -> facial landmarks -> descriptor -> matcher -> attendance record.
9. Discuss limitations: lighting, camera quality, registration quality and privacy.
10. Explain future work: secure backend, encrypted biometric storage, liveness detection, role-based access and institutional database integration.

PROJECT TITLE
SMART FACE: A Facial Recognition-Based Attendance Management System

NOTE
This is a project-defense prototype. It is not intended as a production biometric security system.
